package com.example.simpleasynctask;

import android.os.AsyncTask;
import android.widget.TextView;
import java.util.Random;

public class SimpleAsyncTask extends AsyncTask<Void, Integer, String> {

    private TextView mTextView;

    // Konstruktor untuk mengatur TextView yang akan diperbarui
    public SimpleAsyncTask(TextView tv) {
        mTextView = tv;
    }

    // Menjalankan tugas di latar belakang
    @Override
    protected String doInBackground(Void... voids) {
        Random r = new Random();
        int n = r.nextInt(11);
        int s = n * 200;

        // Membuat thread tertidur untuk waktu acak dengan pembaruan progress
        try {
            for (int i = 0; i <= s; i += 200) {
                Thread.sleep(200);
                publishProgress(i); // Memanggil onProgressUpdate dengan waktu tidur saat ini
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return "Awake at last after sleeping for " + s + " milliseconds!";
    }

    // Memperbarui TextView dengan waktu tidur saat ini
    @Override
    protected void onProgressUpdate(Integer... values) {
        mTextView.setText("Napping... Slept for " + values[0] + " milliseconds so far.");
    }

    // Memperbarui TextView setelah tugas selesai
    @Override
    protected void onPostExecute(String result) {
        mTextView.setText(result);
    }
}
