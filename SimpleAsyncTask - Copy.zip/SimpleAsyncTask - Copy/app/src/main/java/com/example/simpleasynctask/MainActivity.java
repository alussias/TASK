package com.example.simpleasynctask;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Konstanta untuk menyimpan status teks
    private static final String TEXT_STATE = "text_state";

    // Variabel anggota untuk menyimpan TextView
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Inisialisasi mTextView
        mTextView = findViewById(R.id.textView);

        // Memulihkan teks TextView jika ada savedInstanceState
        if (savedInstanceState != null) {
            mTextView.setText(savedInstanceState.getString(TEXT_STATE));
        }

        // Menyediakan insets untuk padding sesuai dengan sistem bar
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Metode untuk memulai AsyncTask saat tombol diklik
    public void startTask(View view) {
        // Mengatur teks pada TextView menjadi "Napping..."
        mTextView.setText("Napping...");

        // Memulai SimpleAsyncTask untuk memperbarui TextView setelah selesai
        new SimpleAsyncTask(mTextView).execute();
    }

    // Override metode onSaveInstanceState untuk menyimpan teks TextView
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Menyimpan teks mTextView ke dalam Bundle
        outState.putString(TEXT_STATE, mTextView.getText().toString());
    }
}
